/**
 * Created by fha on 30-04-2017.
 */
public class Spoon {

    private static int cnt = 0;
    private int num = cnt++;
    @Override
    public String toString() {
        return "Spoon " + num;
    }

}
